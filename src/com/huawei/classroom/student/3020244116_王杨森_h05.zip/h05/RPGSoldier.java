package com.huawei.classroom.student.h05;

public class RPGSoldier extends Object {

	public RPGSoldier() {
		super(50, 10);
		// TODO 自动生成的构造函数存根
	}
	
}