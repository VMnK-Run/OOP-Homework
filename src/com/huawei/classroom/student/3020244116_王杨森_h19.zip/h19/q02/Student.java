package com.huawei.classroom.student.h19.q02;

public class Student extends Person {
    public Student(String name) {
        super(name);
    }
}
