package com.huawei.classroom.student.h19.q02;

public class Person {
    private String name;
    Person(String name) {
        this.name = name;
    }
    public String getName() {
        return this.name;
    }
}
