package com.huawei.classroom.student.h17;

public class Params {

    public static int baseHealth;
    public static int baseRange;
    public static int baseStrength;

    public static int heavyTankHealth;
    public static int heavyTankRange;
    public static int heavyTankStrength;

    public static int mediumTankHealth;
    public static int mediumTankRange;
    public static int mediumTankStrength;

    public static int rifleSoldierHealth;
    public static int rifleSoldierRange;
    public static int rifleSoldierStrength;

    public static int RPGSoldierHealth;
    public static int RPGSoldierRange;
    public static int RPGSoldierStrength;

    public static int dogHealth;
    public static int dogRange;
    public static int dogStrength;

    public static int barrackHealth;
    public static int barrackRange;
    public static int barrackStrength;

    public static int warFactoryHealth;
    public static int warFactoryRange;
    public static int warFactoryStrength;
}
