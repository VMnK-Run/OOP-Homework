package com.huawei.classroom.student.h17;

public abstract class Tank extends Roles{
    public Tank(Player player, int x, int y) {
        super(player, x, y);
    }
}
