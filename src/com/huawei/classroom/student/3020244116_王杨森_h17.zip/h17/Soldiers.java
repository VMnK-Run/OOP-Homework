package com.huawei.classroom.student.h17;

public abstract class Soldiers extends Roles{
    public Soldiers(Player player, int x, int y) {
        super(player, x, y);
    }
}
