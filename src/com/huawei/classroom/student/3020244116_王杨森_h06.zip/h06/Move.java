package com.huawei.classroom.student.h06;

public interface Move {
    void move(int dx, int dy);
}
