package com.huawei.classroom.student.h06;

public enum EnumObjectType {
    barrack, warFactory, rifleSoldier, RPGSoldier, mediumTank, heavyTank, dog,
}
