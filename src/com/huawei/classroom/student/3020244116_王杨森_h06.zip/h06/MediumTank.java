package com.huawei.classroom.student.h06;

public class MediumTank extends Tank{
    public MediumTank(int x, int y) {
        super(x, y, 100, 10, 10);
    }
}
