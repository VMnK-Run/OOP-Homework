package com.huawei.classroom.student.h06;

public class Buildings extends GameObject{
    public Buildings(int x, int y, int health){
        super(x, y, health);
    }
}
