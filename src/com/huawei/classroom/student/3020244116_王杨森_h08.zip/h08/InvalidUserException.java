package com.huawei.classroom.student.h08;

public class InvalidUserException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4114926625852381330L;

	public InvalidUserException() {
		super();
	}
}
