package com.huawei.classroom.student.h08;

public class NoMoneyException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2297029791972042716L;

	public NoMoneyException() {
		super();
	}
}
