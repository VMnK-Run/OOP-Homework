package com.huawei.classroom.student.h08;


/**
 * 这个类不要做任何修改，并且在交作业的时候一并交上来
 * @author Administrator
 *
 */
public interface  AgeCheckInterface {

	public void checkAge(int age)  ;

}
