package com.huawei.classroom.student.h20;

public class E implements C{
    public E() {

    }
}
