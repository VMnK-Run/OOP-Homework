package com.huawei.classroom.student.h07;

public class RPGSoldier extends Soldier {
	public RPGSoldier(  ) {		 
		//super( Param.SOLDIER_HEALTH,Param.SOLDIER_RPG_STRENGTH );
		// TODO Auto-generated constructor stub
	}

}
