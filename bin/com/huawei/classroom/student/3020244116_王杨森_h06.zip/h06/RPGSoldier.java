package com.huawei.classroom.student.h06;

public class RPGSoldier extends Roles{
    public RPGSoldier(int x, int y) {
        super(x, y, 50, 10, 10);
    }
}
